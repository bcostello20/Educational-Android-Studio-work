package com.example.crimeactivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.zip.Inflater;

public class CrimeListFragment extends Fragment
{
    private RecyclerView mCrimeRecyclerView;
    private CrimeAdapter mAdapter;

    private TextView mTextView;
    private TextView mTextView2;

    private Crime mCrime;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_crime_list, container, false);

        mCrimeRecyclerView = (RecyclerView)view.findViewById(R.id.crime_recycler_view);

        mCrimeRecyclerView.setLayoutManager(new LinearLayoutManager((getActivity())));
        //return super.onCreateView(inflater, container, savedInstanceState);

        updateUI();

        return view;
    }

    private void updateUI()
    {
        CrimeLab crimeLab = CrimeLab.get(getActivity());

        List<Crime> crimelist = crimeLab.getCrimeList();

        mAdapter = new CrimeAdapter(crimelist);

        mCrimeRecyclerView.setAdapter(mAdapter);
    }

    private  class CrimeHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        public CrimeHolder(LayoutInflater inflater, ViewGroup parent)
        {
            super(inflater.inflate(R.layout.list_item_crime, parent, false));

            mTextView = (TextView)itemView.findViewById(R.id.crime_title);
            mTextView2 = (TextView)itemView.findViewById(R.id.crime_date);

            mTextView.setOnClickListener(this);
            mTextView2.setOnClickListener(this);
        }

        @Override
        public void onClick(View view)
        {
            //Toast toast = Toast.makeText(getActivity(), mCrime.getTitle() + " Clicked", Toast.LENGTH_SHORT);
            //toast.show();

            //Intent intent = new Intent(getActivity(), MainActivity.class);
            //startActivity(intent);

            Intent intent = new Intent(MainActivity.newIntent(getActivity(), mCrime.getID()));
            startActivity(intent);
        }
    }

    private class CrimeAdapter extends RecyclerView.Adapter<CrimeHolder>
    {
        private List<Crime> mCrimes;

        public CrimeAdapter(List<Crime> crimeList)
        {
            mCrimes = crimeList;
        }

        @NonNull
        @Override
        public CrimeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
        {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());

            CrimeHolder crimeHolder = new CrimeHolder(layoutInflater, parent);

            return crimeHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull CrimeHolder holder, int position)
        {
            Crime crime;
            crime = mCrimes.get(position);
            bind(crime);
        }

        @Override
        public int getItemCount()
        {
            return mCrimes.size();
        }
    }

    public void bind(Crime crime)
    {
        mCrime = crime;
        mTextView.setText(mCrime.getTitle());
        mTextView2.setText(mCrime.getDate().toString());
    }

}
