package com.example.crimeactivity;

import java.util.Date;
import java.util.UUID;

public class Crime
{
    // Member variables
    private UUID mId; // The crime id
    private String mTitle; // Title UI
    private Date mDate; // The date
    private boolean mSolved; // Is the crime solved?

    // The constructor - sets the default values for the Id and date
    public Crime()
    {
        mId = UUID.randomUUID();
        mDate = new Date();
    }

    // Get methods
    public UUID getID()
    {
        return mId;
    } // Get the crime id

    public String getTitle()
    {
        return mTitle;
    } // Get the crime title

    public Date getDate()
    {
        return mDate;
    } // Get the crime date

    public boolean isSolved()
    {
        return mSolved;
    } // Crime is solved or not solved

    // Set methods
    public void setTitle(String title)
    {
        this.mTitle = title;
    } // Set the crime title

    public void setDate(Date date)
    {
        this.mDate = date;
    } // Set the crime date

    public void setSolved(boolean solved)
    {
        this.mSolved = solved;
    } // Set whether the crime is solved or not solved

}
