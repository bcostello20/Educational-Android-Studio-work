package com.example.crimeactivity;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CrimeLab extends Crime
{
    static CrimeLab sCrimeLab;

    private List<Crime> sCrimes;

    // The constructor
    private CrimeLab(Context context)
    {
        sCrimes = new ArrayList<>();

        for (int i = 0; i < 100; i++)
        {
            Crime aCrime = new Crime();
            aCrime.setTitle("Crime #" + i);
            aCrime.setSolved(i%2==0);
            sCrimes.add(aCrime);
        }
    }

    public static CrimeLab get(Context context)
    {
        if (sCrimeLab == null)
        {
            sCrimeLab = new CrimeLab(context);
        }

        return sCrimeLab;
    }

    public List<Crime> getCrimeList()
    {
        return sCrimes;
    }

    public Crime getCrime(UUID uuid)
    {
        for (Crime crime : sCrimes)
        {
            if (crime.getID().equals(uuid))
                return crime;
        }
        return null;
    }

}