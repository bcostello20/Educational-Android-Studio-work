package com.example.crimeactivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import androidx.appcompat.app.ActionBar;
import androidx.fragment.app.Fragment;

import java.util.UUID;

public class CrimeFragment extends Fragment
{
    private EditText crimeTitle; // The crime title to be entered
    private Button buttonCrimeDate; // The crime date button
    private CheckBox mSolvedCheckBox; // The solved or unsolved checkbox

    //Crime mCrime = new Crime(); // Creates an instance of the Crime object

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        UUID crimeId = (UUID)getActivity().getIntent().getSerializableExtra(MainActivity.EXTRA_CRIME_ID);
        Crime mCrime = CrimeLab.get(getActivity()).getCrime(crimeId);
        //mCrime.getTitle();
        //mSolvedCheckBox.setChecked(mCrime.isSolved());

    }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View v = inflater.inflate(R.layout.fragment_crime, container, false);

            crimeTitle = (EditText)v.findViewById(R.id.crime_title); // Inflates the crime title EditText

            final TextWatcher watcher = new TextWatcher()
            {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2)
                {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2)
                {
                    crime.setTitle(crimeTitle.getText().toString()); // Get whatever is typed into the EditText
                }

                @Override
                public void afterTextChanged(Editable editable)
                {

                }
            };

            buttonCrimeDate = (Button)v.findViewById(R.id.crime_date); // Inflate the crime date button

            buttonCrimeDate.setText(crime.getDate().toString()); // Set the text for the button
            buttonCrimeDate.setEnabled(false); // Make the button unclickable

            mSolvedCheckBox = (CheckBox)v.findViewById(R.id.crime_solved); // Inflate the solved/unsolved checkbox

            mSolvedCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
                {
                    crime.setSolved(isChecked); // On clicked, add a check to the checkbox
                }
            });

            return v; // return the view v
        }

}
