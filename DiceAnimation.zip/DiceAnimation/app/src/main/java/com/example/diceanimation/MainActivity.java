package com.example.diceanimation;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Animatable;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView dice1;
    private ImageView dice2;
    private Button roll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inflate the ImageViews and Button
         dice1 = (ImageView) findViewById(R.id.imageView1);
         dice2 = (ImageView) findViewById(R.id.imageView2);
         roll = (Button) findViewById(R.id.rollDices);

        // Set up OnClickListener for roll button
        roll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // The dice animations
                final Animation anim1 = AnimationUtils.loadAnimation(MainActivity.this, R.anim.shake);
                final Animation anim2 = AnimationUtils.loadAnimation(MainActivity.this, R.anim.shake);


                final Animation.AnimationListener animationListener = new Animation.AnimationListener()
                {
                    @Override
                    public void onAnimationStart(Animation animation)
                    {

                    }

                    @Override
                    public void onAnimationEnd(Animation animation)
                    {
                        int min = 1;
                        int max = 6;
                        int random = new Random().nextInt(max - min) + min;

                        int res = getResources().getIdentifier("dice_" + random, "drawable", "com.example.DiceAnimation");

                        if (animation == anim1)
                        {
                            dice1.setImageResource(res);
                        }
                        else if (animation == anim2)
                        {
                            dice2.setImageResource(res);
                        }
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation)
                    {

                    }
                };

                anim1.setAnimationListener(animationListener);
                anim2.setAnimationListener(animationListener);

                dice1.startAnimation(anim1);
                dice2.startAnimation(anim2);
            }
        });


    }
}
