package com.example.simulatediceroll;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Random;

public class MainActivity extends AppCompatActivity
{
    Button button; // Name of the random dice roll Button
    int playerPoints = 0; // The player's score
    int housePoints = 0; // The house's score

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up the button ID and OnClickListener method
        button = (Button)findViewById(R.id.buttonRandomNumber);
        button.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View view)
            {
                // Let's generate a random number on button click
                final int min = 1; // Lowest value
                final int max = 6; // Highest value

                // Setting up our two random dice here
                // Using the Random method call
                Random dice1 = new Random();
                // First random dice number between 1 and 6
                int i1 = dice1.nextInt(max - min + 1) + min;
                // Call another Random
                Random dice2 = new Random();
                // Second random dice number between 1 and 6
                int i2 = dice2.nextInt(max - min + 1) + min;

                // Display the first random dice number to the randomNumberView TextView
                final TextView randomNumberView = (TextView)findViewById(R.id.randomNumberView);
                randomNumberView.setText(String.valueOf(i1));

                // Display the second random dice number to the randomNumberView2 TextView
                final TextView randomNumberView2 = (TextView)findViewById(R.id.randomNumberView2);
                randomNumberView2.setText(String.valueOf(i2));

                // Decide which Toast to show based on the sum of the two random dice
                if (i1 + i2 == 7 | i1 + i2 == 11)
                {
                    // Set up the Toast
                    Context context = getApplicationContext();
                    CharSequence winText = "You win";
                    int duration = Toast.LENGTH_SHORT;

                    // Create and add a point to the player's score
                    playerPoints = ++playerPoints;
                    final TextView playerPointsTextView = (TextView)findViewById(R.id.playerPointsTextView);
                    playerPointsTextView.setText(String.valueOf(playerPoints));

                    Toast toast = Toast.makeText(context, winText, duration);
                    toast.show();
                }
                else if (i1 + i2 == 2 | i1 + i2 == 3 | i1 + i2 == 12)
                {
                    // Set up the Toast
                    Context context2 = getApplicationContext();
                    CharSequence houseWinText = "The house wins";
                    int duration2 = Toast.LENGTH_SHORT;

                    // Create and add a point to the house's score
                    housePoints = ++housePoints;
                    final TextView housePointsTextView = (TextView)findViewById(R.id.housePointsTextView);
                    housePointsTextView.setText(String.valueOf(housePoints));

                    Toast toast2 = Toast.makeText(context2, houseWinText, duration2);
                    toast2.show();
                }
                else if (i1 + i2 == 4 | i1 + i2 == 5 | i1 + i2 == 6 | i1 + i2 == 8 | i1 + i2 == 9
                | i1 + i2 == 10)
                {
                    // Set up the Toast
                    Context context3 = getApplicationContext();
                    CharSequence tryAgainText = "Please try again";
                    int duration3 = Toast.LENGTH_SHORT;

                    Toast toast3 = Toast.makeText(context3, tryAgainText, duration3);
                    toast3.show();
                }

            }
        });

    }
}