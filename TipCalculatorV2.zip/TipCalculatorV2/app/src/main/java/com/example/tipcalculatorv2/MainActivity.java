// MainActivity.java
// Calculates a bill total based on a tip percentage
package com.example.tipcalculatorv2;

import androidx.appcompat.app.AppCompatActivity; // base class

import android.os.Bundle; // for saving state information
import android.text.Editable; // for EditText event handling
import android.text.TextWatcher; // EditText listener
import android.view.View;
import android.widget.EditText; // for bill amount input
import android.widget.SeekBar; // for changing the tip percentage
import android.widget.SeekBar.OnSeekBarChangeListener; //SeekBar listener
import android.widget.TextView; // for displaying text
import android.widget.Button; // for usage of buttons

import java.text.NumberFormat; // for currency formatting

//MainActivity class for the Tip Calculator app
public class MainActivity extends AppCompatActivity
{

    // currency and percent formatter objects
    private static final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
    private static final NumberFormat percentFormat = NumberFormat.getPercentInstance();

    // member variables
    private double billAmount = 0.0; // bill amount entered by the user
    private double percent = 0.15; // initial tip percentage
    private double tax = 0.0;
    private double tip = 0.0;
    private double total = 0.0;
    private int partySize = 0;
    private TextView amountTextView; // shows formatted bill amount
    private TextView percentTextView; // shows tip percentage
    private TextView tipTextView; // shows calculated tip amount
    private TextView totalTextView; // shows calculated total bill amount
    // additions for advanced app
    private TextView taxTextView;
    private TextView partySizeTextView;

    // the activity is first created, then this method will be called
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState); // call superclass's version
        setContentView(R.layout.activity_main); // inflate the GUI

        Button mButton = findViewById(R.id.beforeTaxButton);
        mButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //calculate the tip and total
                tip = billAmount * percent;
                total = billAmount + tip;
                //display tip and total formatted as currency
                tipTextView.setText(currencyFormat.format(tip));
                totalTextView.setText(currencyFormat.format(total));
            }
        });

        Button mButton2 = findViewById(R.id.afterTaxButton);
        mButton2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //calculate the tip and total after tax
                tip = billAmount * percent + tax;
                total = billAmount + tip;
                //display tip and total formatted as currency after tax
                tipTextView.setText(currencyFormat.format(tip));
                totalTextView.setText(currencyFormat.format(total));
            }
        });

        // get references to the manipulated TextViews
        amountTextView = (TextView) findViewById(R.id.amountTextView);
        percentTextView = (TextView) findViewById(R.id.percentTextView);
        tipTextView = (TextView) findViewById(R.id.tipTextView);
        totalTextView = (TextView) findViewById(R.id.totalTextView);
        // additions for advanced the app
        taxTextView = (TextView) findViewById(R.id.taxTextView);
        partySizeTextView = (TextView) findViewById(R.id.partySizeTextView);

        tipTextView.setText(currencyFormat.format(0));
        totalTextView.setText(currencyFormat.format(0));

        // set amountEditText's TextWatcher
        EditText amountEditText = (EditText) findViewById(R.id.amountEditText);
        amountEditText.addTextChangedListener(amountEditTextWatcher);

        // set taxEditText's TextWatcher
        EditText taxEditText = (EditText) findViewById(R.id.taxEditText);
        taxEditText.addTextChangedListener((taxEditTextWatcher));

        // set percentSeekBar's OnSeekBarChangeListener
        SeekBar percentSeekBar = (SeekBar) findViewById(R.id.percentSeekBar);
        percentSeekBar.setOnSeekBarChangeListener(seekBarListener);

        // set partySizeEditText's TextWatcher
        EditText partySizeEditText = (EditText) findViewById(R.id.partySizeEditText);
        partySizeEditText.addTextChangedListener((partySizeEditTextWatcher));
    }

    //calculate and display tip and total amounts
    public void calculate()
    {
        // format percent and display in percentTextView
        percentTextView.setText(percentFormat.format(percent));

        //calculate the tip and total
        //double tip = billAmount * percent; // not calculating tip here anymore
        //double total = billAmount + tip; // not calculating total here anymore

        //display tip and total formatted as currency
        //tipTextView.setText(currencyFormat.format(tip));
        //totalTextView.setText(currencyFormat.format(total));
    }

    // listener object for the SeekBar's progress changed events
    private final OnSeekBarChangeListener seekBarListener = new SeekBar.OnSeekBarChangeListener()
    {
        // update percent, then call calculate
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
        {
            percent = progress/100.0; // set percent based on progress
            calculate(); // calculate and display tip and total
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar){}

        @Override
        public void onStopTrackingTouch(SeekBar seekBar){}
    };

    // listener object for the EditText's text-changed events
    private final TextWatcher amountEditTextWatcher = new TextWatcher()
    {
        // called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            try
            {
                // get bill amount and display currency formatted value
                billAmount = Double.parseDouble(s.toString()) / 100.0;
                amountTextView.setText(currencyFormat.format(billAmount));
            } catch (NumberFormatException e) // if s is empty or non-numeric
            {
                amountTextView.setText("");
                billAmount = 0.0;
            }

            calculate(); // update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s){}

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after){}
    };

    // listener object for the taxEditText
    private final TextWatcher taxEditTextWatcher = new TextWatcher()
    {

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2)
        {
            try
            {
                tax = Double.parseDouble(charSequence.toString()) / 100.0;
                taxTextView.setText(percentFormat.format(tax));
            }
            catch (NumberFormatException n)
            {
                taxTextView.setText("");
                tax = 0.0;
            }

            calculate();
        }

        @Override
        public void afterTextChanged(Editable charSequence){}

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2){}
    };

    // listener object for the partySizeEditText
    private final TextWatcher partySizeEditTextWatcher = new TextWatcher()
    {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2)
        {
            try
            {
                partySizeTextView.setText(partySize);
            }
            catch (NumberFormatException o)
            {
                partySizeTextView.setText("");
                partySize = 0;
            }
        }

        @Override
        public void afterTextChanged(Editable editable) { }
    };

}