package com.example.geoquiz;

public class Question
{
    // Member variables
    private int mTextResId;
    private boolean mAnswerTrue;

    // Constructor that takes in the member variables and assigns them to values
    public Question(int textResId, boolean answerTrue)
    {
        mTextResId = textResId;
        mAnswerTrue = answerTrue;
    }

    // Get method

    // Gets the TextResId and returns it
    public int getTextResId()
    {
        return mTextResId;
    }

    // Set methods

    // Sets the mTextResId to be what textResId is
    public void setTextResId(int textResId)
    {
        mTextResId = textResId;
    }

    // Returns true if answer is correct
    public boolean isAnswerTrue()
    {
        return mAnswerTrue;
    }

    // Sets the mAnswerTrue to be what answerTrue is
    public void setAnswerTrue(boolean answerTrue)
    {
        mAnswerTrue = answerTrue;
    }
}
