package com.example.geoquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class CheatActivity extends AppCompatActivity
{
    public Boolean mAnswerIsTrue;

    private Button showAnswer;

    private TextView showAnswerTextView;

    final static public String EXTRA_ANSWER_IS_TRUE = "com.example.geoquiz.answer_is_true";
    static public Intent newIntent(Context con, Boolean b)
    {
        Intent toCheat = new Intent( con, CheatActivity.class);
        toCheat.putExtra(EXTRA_ANSWER_IS_TRUE, b);
        return toCheat;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cheat);

        mAnswerIsTrue = getIntent().getBooleanExtra(EXTRA_ANSWER_IS_TRUE, false);

        showAnswer = (Button)findViewById(R.id.show_answer_button);

        showAnswerTextView = (TextView)findViewById(R.id.showAnswerTextView);

        showAnswer.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (mAnswerIsTrue = true)
                    showAnswerTextView.setText(R.string.true_button);
                else
                    showAnswerTextView.setText(R.string.false_button);
            }
        });
    }

}