package com.example.geoquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity; // Imports standard constants and tools for placing an object within a larger container.
import android.view.View;
import android.widget.Button;
import android.widget.Toast; // This imports the toast, which provides simple feedback to the user in a small popup.
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{

    private Button mTrueButton; // A GUI button that says True
    private Button mFalseButton; // A GUI button that says False

    private Button mNextButton; // A GUI button that says Next

    private Button mCheatButton;

    public Boolean truthValue;

    private TextView mQuestionTextView;

    private Question[] mQuestionsBank = new Question[]
            {
                 new Question(R.string.question_australia, true),
                 new Question(R.string.question_oceans, true),
                 new Question(R.string.question_mideast, false),
                 new Question(R.string.question_africa, false),
                 new Question(R.string.question_americas, true),
                 new Question(R.string.question_asia, true),
            };

    private int mCurrentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mQuestionTextView = (TextView)findViewById(R.id.question_text_view);

        mTrueButton = (Button) findViewById(R.id.true_button);

        mNextButton = (Button)findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                mCurrentIndex = (mCurrentIndex + 1) % mQuestionsBank.length;
                updateQuestion();
            }
        });

        updateQuestion();

        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Display the toast1 popup to the user at the top of the screen, saying they are correct.
//                Toast toast1 = Toast.makeText(MainActivity.this, R.string.correct_toast, Toast.LENGTH_SHORT);
//
//                toast1.setGravity(Gravity.TOP, 0, 0);
//                toast1.show();

                checkAnswer(true);
            }
            });

        mFalseButton = (Button) findViewById(R.id.false_button);
        mFalseButton.setOnClickListener(new View.OnClickListener()

            {
                @Override
                public void onClick (View view)
                {
                    // Display the toast2 popup to the user at the top of the screen, saying they are incorrect.
//                    Toast toast2 = Toast.makeText(MainActivity.this, R.string.incorrect_toast, Toast.LENGTH_SHORT);
//
//                    toast2.setGravity(Gravity.TOP, 0 , 0);
//                    toast2.show();

                    checkAnswer(false);
                }
        });

        mCheatButton = (Button)findViewById(R.id.cheat_button);
        mCheatButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //Intent toCheat = new Intent(MainActivity.this, CheatActivity.class);

                truthValue = mQuestionsBank[mCurrentIndex].isAnswerTrue();

                Intent cheat = CheatActivity.newIntent(MainActivity.this, truthValue);

                startActivity(cheat);
            }
        });

    }

    public void updateQuestion()
    {
        int question = mQuestionsBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);
    }

    public void checkAnswer(Boolean answer)
    {
        int messageId = 0;

        if (answer == mQuestionsBank[mCurrentIndex].isAnswerTrue())
        {
            messageId = R.string.correct_toast;
        }
        else {
            messageId = R.string.incorrect_toast;
        }
        Toast toast3 = Toast.makeText(this, messageId, Toast.LENGTH_SHORT);
        toast3.show();
    }

}