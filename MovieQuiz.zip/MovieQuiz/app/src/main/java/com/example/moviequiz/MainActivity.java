package com.example.moviequiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // Variables
    private Button mNextButton; // A GUI button that says Next
    private Button mCheckButton; // A GUI button that says Check Answer
    private EditText mAnswerEditText; // A GUI text field for the user to type their answer into
    private TextView mQuestionTextView; // A GUI text field to display the math question

    // An array of six questions for the user to answer
    private Question[] mQuestionsBank = new Question[]
            {
                    new Question(R.string.question_one, "Rosebud"),
                    new Question(R.string.question_two, "Anne Bancroft"),
                    new Question(R.string.question_three, "Snow White and the Seven Dwarfs"),
                    new Question(R.string.question_four, "Red"),
                    new Question(R.string.question_five, "Big"),
                    new Question(R.string.question_six, "The Jazz Singer"),
                    new Question(R.string.question_seven, "Nakatomi Plaza"),
                    new Question(R.string.question_eight, "Chocolate"),
                    new Question(R.string.question_nine, "The Last House on the Left"),
                    new Question(R.string.question_ten, "Wilson Phillips"),
            };

    private int mCurrentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up the question TextView object
        mQuestionTextView = (TextView)findViewById(R.id.questionTextView);

        // Set up the next Button object
        mNextButton = (Button)findViewById(R.id.nextButton);
        mNextButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                mCurrentIndex = (mCurrentIndex + 1) % mQuestionsBank.length;
                updateQuestion();
            }
        });

        updateQuestion();

        // Set up the anwer EditText object
        mAnswerEditText = (EditText)findViewById(R.id.editTextGetAnswer);
        // Set up the check answer Button object
        mCheckButton = (Button)findViewById(R.id.checkButton);



        mCheckButton.setOnClickListener(new View.OnClickListener()
        {
            int guess = 1; // user's guess count
            @Override
            public void onClick(View view)
            {

                Toast toast2 = Toast.makeText(MainActivity.this, "Incorrect", Toast.LENGTH_SHORT);
                Toast toast3 = Toast.makeText(MainActivity.this, "You are almost there!", Toast.LENGTH_SHORT);
                Toast toast4 = Toast.makeText(MainActivity.this, "The correct answer is: " + mQuestionsBank[mCurrentIndex].getAnswer(), Toast.LENGTH_SHORT);

                // If the answer of the current question matches the answer typed in by the user...
                if (mQuestionsBank[mCurrentIndex].isAnswerTrue() == (String.valueOf(mAnswerEditText.getText())))
                {
                    // Display a message saying "Nice work!"
                    Toast toast1 = Toast.makeText(MainActivity.this, "Nice work!", Toast.LENGTH_SHORT);
                    toast1.show();
                    guess += 1;
                }
                // If the answer of the current question does NOT match the answer typed in by the user...
                else if (guess == 1 && mQuestionsBank[mCurrentIndex].isAnswerTrue() != (String.valueOf(mAnswerEditText.getText())))
                {
                    toast2.show();
                    guess += 1;
                }
                // If it's the second guess say You're almost there!
                else if (guess == 2 && mQuestionsBank[mCurrentIndex].isAnswerTrue() != (String.valueOf(mAnswerEditText.getText())))
                {
                    toast3.show();
                    guess += 1;
                }
                // If it's the third guess or greater show the answer
                else if (guess == 3)
                {
                    toast4.show();
                }
            }
        });

    }

    // updateQuestion method gets the next question
    public void updateQuestion()
    {
        int question = mQuestionsBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);
    }


}