package com.example.moviequiz;

public class Question
{
    // Member variables
    private int mTextResId;
    private String mAnswer;

    // Constructor that takes in the member variables and assigns them to values
    public Question(int textResId, String answer)
    {
        mTextResId = textResId;
        mAnswer = answer;
    }

    // Get method

    // Gets the TextResId and returns it
    public int getTextResId()
    {
        return mTextResId;
    }

    // Gets the string answer for a question
    public String getAnswer()
    {
        return mAnswer;
    }

    // Set methods

    // Sets the mTextResId to be what textResId is
    public void setTextResId(int textResId)
    {
        mTextResId = textResId;
    }

    // Returns the string if answer is correct
    public String isAnswerTrue()
    {
        return mAnswer;
    }

    // Sets the mAnswer to be what answer is
    public void setAnswerTrue(String answer)
    {
        mAnswer = answer;
    }
}
